
public class CalculaDNI {


	public static void main(String[] args) {
		
		Persona p = new Persona();
		
		p.obtenDatos();
		
		p.muetraDatos();
	
	}
	

}
