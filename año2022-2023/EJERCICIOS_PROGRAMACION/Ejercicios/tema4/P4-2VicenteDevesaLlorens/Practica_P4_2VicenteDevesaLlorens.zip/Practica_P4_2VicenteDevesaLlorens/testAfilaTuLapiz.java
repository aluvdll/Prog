package Pratica_p4_2_;

public class testAfilaTuLapiz {
	int height;
	int width; 
	
	static int calcArea(int height, int width) {
		return height * width;
	}
	public static void main(String[] args) {
		//int a = calcArea(7,12); -no compila
		//short c = 7;// -si que compila, declara una variable tipo primitiva short llamada c con un varo de 7;
		//calcArea(c,15); - no compila no respeta los tipos de datos.
		//int d = calcArea(57); - no respeta el argumento solo le pasa 1 al metodo y el metodo tiene 2 parametros.
		//System.out.println(calcArea(2,3));
		//long t = 42; //si que compila
		//int f = calcArea(t,17); no compila.
		//int g = calcArea(); no compila.
		//calcArea();
		//int h = calcArea(4,20); 
		//int j = calcArea(2,3,5); no compila se le pasan 3 argumentos cuando el metodo solo tiene 2 parametros.
		//int g = calcArea();
		//calcArea(); no le passa ningun argumenteo.
		//byte h = calcArea(4,20);  no coinciden los tipos de varibales primitivas
		//int j = calcArea(2,3,5);
	}
}
