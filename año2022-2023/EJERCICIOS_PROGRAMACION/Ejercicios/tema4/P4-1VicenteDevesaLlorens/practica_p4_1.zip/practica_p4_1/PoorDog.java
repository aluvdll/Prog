// El ejercicio PoorDog lo declaro en dos doc distintos.
// El ejercicio GoodDog lo declaro todo en un mismo doc .java
package practica_p4_1;

class PoorDog {
	private int size;
	private String name;
	
	public int getSize() {	// si que compila pero al no inicializar la variable con un dato se le asigna el valor por defecto de java.	
		return size;
	}
	
	public String getName() { // si que compila pero al no inicializar la variable con un dato se le asigna el valor por defecto de java.
	return name;
	}
}


